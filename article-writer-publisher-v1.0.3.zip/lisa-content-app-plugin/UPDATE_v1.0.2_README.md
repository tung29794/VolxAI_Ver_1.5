# 🚀 Article Writer Publisher Plugin v1.0.2

## ✨ What's New

Version 1.0.2 adds **anti-duplicate functionality** to prevent WordPress from creating posts with slug-2, slug-3 suffixes.

### New Features

#### 1️⃣ Check Slug API
- Kiểm tra xem slug có tồn tại trên WordPress hay không
- Endpoint: `GET /wp-json/article-writer/v1/check-slug?slug=xxx&post_type=post`

#### 2️⃣ Delete Post API  
- Xóa post cũ trước khi tạo post mới
- Endpoint: `POST /wp-json/article-writer/v1/delete/{post_id}`

### How It Works

```
┌─────────────┐
│  VolxAI API │
└──────┬──────┘
       │ 1. Check slug exists?
       ▼
┌─────────────────┐
│ WordPress Plugin│ ─── GET /check-slug
└──────┬──────────┘
       │ 2. Yes, post ID=123
       ▼
┌─────────────────┐
│ WordPress Plugin│ ─── POST /delete/123
└──────┬──────────┘
       │ 3. Old post deleted
       ▼
┌─────────────────┐
│ WordPress Plugin│ ─── POST /publish (clean slug!)
└─────────────────┘
```

## 📦 Quick Deploy

### Option 1: WordPress Admin (Easiest)

1. Download: `article-writer-publisher-v1.0.2.zip`
2. WordPress Admin → Plugins → Add New → Upload Plugin
3. Choose file → Install Now → Activate

### Option 2: Manual FTP

1. Extract `article-writer-publisher-v1.0.2.zip`
2. Upload to `/wp-content/plugins/`
3. Activate in WordPress Admin

## 🧪 Test the Plugin

After installing, test the new APIs:

### Test 1: Check Slug
```bash
curl "https://yoursite.com/wp-json/article-writer/v1/check-slug?slug=test" \
  -H "X-Article-Writer-Token: YOUR_TOKEN"
```

### Test 2: Delete Post
```bash
curl -X POST "https://yoursite.com/wp-json/article-writer/v1/delete/123" \
  -H "X-Article-Writer-Token: YOUR_TOKEN"
```

## ✅ Benefits

- ✅ **No more slug-2, slug-3** - Clean URLs always
- ✅ **Auto cleanup** - Old posts deleted automatically
- ✅ **Backward compatible** - All old features still work
- ✅ **No database changes** - Safe upgrade
- ✅ **Comprehensive logging** - Easy debugging

## 📚 Full Documentation

- [CHANGELOG.md](./CHANGELOG.md) - Version history
- [DEPLOYMENT_GUIDE_v1.0.2.md](./DEPLOYMENT_GUIDE_v1.0.2.md) - Detailed deployment steps
- [README.md](./README.md) - Original plugin documentation

## 🔗 Integration with VolxAI

This plugin works with VolxAI v1.5+ backend that includes:
- Automatic slug checking before publishing
- Old post deletion when duplicates detected
- Clean post creation with original slug

No changes needed on VolxAI side - already deployed! ✅

## 🆘 Support

Issues? Check:
1. WordPress error logs
2. Plugin logs: `/wp-content/plugins/article-writer-publisher/logs/`
3. Enable WP_DEBUG for detailed errors

## 📋 Version Compatibility

- WordPress: 5.0+
- PHP: 7.4+
- VolxAI Backend: v1.5+

---

**Ready to deploy?** 🚀

Just upload `article-writer-publisher-v1.0.2.zip` to WordPress and activate!
