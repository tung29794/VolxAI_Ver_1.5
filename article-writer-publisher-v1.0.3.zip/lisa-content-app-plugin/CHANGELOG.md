# Changelog

## Version 1.0.3 (January 5, 2026)

### 🐛 Bug Fixes

#### Fixed Sync Not Detecting New Posts
- **Issue:** Khi khách hàng tạo bài mới trên WordPress, chức năng đồng bộ không quét lại để lấy bài mới
- **Root Cause:** WordPress cache query results
- **Solution:** Added cache-busting parameters to ensure fresh results on every sync:
  - `cache_results => false` - Disable result caching
  - `update_post_meta_cache => false` - Skip meta cache update
  - `update_post_term_cache => false` - Skip term cache update  
  - `suppress_filters => true` - Bypass query filters that might cache

### 🔧 Improvements

- Force fresh database query on every sync request
- Ensure newest posts always appear first (ORDER BY date DESC)
- Better logging for sync operations

### 📝 Technical Details

**Modified File:** `includes/class-api-handler.php`
- Function: `handle_get_posts()`
- Added WP_Query cache-busting arguments

**Impact:**
- ✅ Mỗi lần nhấn "Đồng bộ" sẽ query trực tiếp database
- ✅ Luôn lấy bài mới nhất
- ✅ Không bị ảnh hưởng bởi WordPress cache

---

## Version 1.0.2 (January 5, 2026)

### ✨ New Features

#### 1. Check Slug Existence API
- **Endpoint:** `GET /wp-json/article-writer/v1/check-slug`
- **Purpose:** Check if a slug already exists for a specific post type
- **Parameters:**
  - `slug` (required): The slug to check
  - `post_type` (optional, default: 'post'): The post type to check
- **Response:**
  ```json
  {
    "success": true,
    "exists": true,
    "post_id": 123,
    "post_title": "Example Post",
    "post_status": "publish",
    "post_url": "https://example.com/example-post",
    "post_type": "post"
  }
  ```

#### 2. Delete Post API
- **Endpoint:** `POST /wp-json/article-writer/v1/delete/{post_id}`
- **Purpose:** Delete a post by ID
- **Parameters:**
  - `id` (required, in URL): The post ID to delete
  - `force` (optional, default: true): Force permanent deletion (bypass trash)
- **Response:**
  ```json
  {
    "success": true,
    "message": "Post deleted successfully",
    "post_id": 123,
    "post_title": "Example Post",
    "post_slug": "example-post",
    "post_type": "post",
    "force_deleted": true
  }
  ```

### 🔧 Improvements

- Added comprehensive logging for slug checking and post deletion
- Improved error handling with proper HTTP status codes
- Better validation for input parameters
- Post queries optimized with `no_found_rows` and cache flags

### 🐛 Bug Fixes

- None in this version

### 📝 Notes

These new endpoints prevent duplicate posts when publishing from VolxAI:
1. Before creating a post, check if slug exists
2. If slug exists, delete the old post
3. Create new post with clean slug (no -2, -3 suffixes)

---

## Version 1.0.1

- Previous updates (see PLUGIN_UPDATES_v1.0.1.md)

## Version 1.0.0

- Initial release
- Basic publish and update functionality
- Token management
- Draft retrieval
- Post syncing
- Post types and taxonomies support
- Image upload functionality
