# Plugin Deployment Guide v1.0.2

## 🎯 What's New in v1.0.2

✅ **Check Slug API** - Kiểm tra slug có tồn tại không
✅ **Delete Post API** - Xóa post cũ để tránh duplicate
✅ **Anti-Duplicate System** - Tự động xóa bài cũ trước khi tạo mới

## 📦 Deployment Steps

### Method 1: Manual Upload via WordPress Admin (Recommended)

1. **Zip the plugin folder**
   ```bash
   cd /Users/tungnguyen/VolxAI_2_1_26/VolxAI_Ver_1.5
   zip -r lisa-content-app-plugin-v1.0.2.zip lisa-content-app-plugin/
   ```

2. **Go to WordPress Admin**
   - Navigate to: `Plugins → Add New → Upload Plugin`
   - Click "Choose File" and select `lisa-content-app-plugin-v1.0.2.zip`
   - Click "Install Now"
   - Activate the plugin

3. **Verify Installation**
   - Go to: `Settings → Article Writer`
   - Check version shows: **1.0.2**
   - Your API token should still be there

### Method 2: FTP/SFTP Upload

1. **Connect to your server via FTP/SFTP**

2. **Navigate to plugins directory**
   ```
   /wp-content/plugins/
   ```

3. **Backup old version** (recommended)
   ```bash
   # On server
   mv article-writer-publisher article-writer-publisher-backup
   ```

4. **Upload new version**
   - Upload entire `lisa-content-app-plugin` folder
   - Rename to `article-writer-publisher` if needed

5. **Go to WordPress Admin**
   - Navigate to: `Plugins`
   - Deactivate then Reactivate the plugin

### Method 3: SSH/Command Line

```bash
# On your local machine
cd /Users/tungnguyen/VolxAI_2_1_26/VolxAI_Ver_1.5
zip -r plugin.zip lisa-content-app-plugin/

# Upload to server
scp -P 2210 plugin.zip jybcaorr@ghf57-22175.azdigihost.com:/home/jybcaorr/

# On server
ssh -p 2210 jybcaorr@ghf57-22175.azdigihost.com
cd ~/your-wordpress/wp-content/plugins/
# Backup
mv article-writer-publisher article-writer-publisher-backup
# Extract
unzip ~/plugin.zip
mv lisa-content-app-plugin article-writer-publisher
# Set permissions
chown -R www-data:www-data article-writer-publisher
chmod -R 755 article-writer-publisher
```

## 🧪 Testing New APIs

### Test Check Slug API

```bash
curl -X GET "https://yoursite.com/wp-json/article-writer/v1/check-slug?slug=test-post&post_type=post" \
  -H "X-Article-Writer-Token: YOUR_API_TOKEN"
```

**Expected Response (if slug exists):**
```json
{
  "success": true,
  "exists": true,
  "post_id": 123,
  "post_title": "Test Post",
  "post_status": "publish",
  "post_url": "https://yoursite.com/test-post",
  "post_type": "post"
}
```

### Test Delete Post API

```bash
curl -X POST "https://yoursite.com/wp-json/article-writer/v1/delete/123" \
  -H "X-Article-Writer-Token: YOUR_API_TOKEN"
```

**Expected Response:**
```json
{
  "success": true,
  "message": "Post deleted successfully",
  "post_id": 123,
  "post_title": "Test Post",
  "post_slug": "test-post",
  "post_type": "post",
  "force_deleted": true
}
```

## ✅ Verification Checklist

After deployment, verify:

- [ ] Plugin shows version 1.0.2 in WordPress Admin
- [ ] Existing API token still works
- [ ] Old publish functionality still works
- [ ] Check Slug API returns correct response
- [ ] Delete Post API can delete a test post
- [ ] VolxAI can publish without creating slug-2 duplicates

## 🔄 Rollback (If Needed)

If something goes wrong:

```bash
# On server
cd ~/your-wordpress/wp-content/plugins/
rm -rf article-writer-publisher
mv article-writer-publisher-backup article-writer-publisher
```

Then reactivate plugin in WordPress Admin.

## 📝 Notes

- **No database changes** in this version - safe to upgrade
- **No settings changes** - your API tokens remain unchanged
- **Backward compatible** - all old API endpoints still work
- **Logging enabled** - check logs for debugging if needed

## 🆘 Troubleshooting

### API returns 404
- Check WordPress permalink settings (Settings → Permalinks → Save)
- Ensure plugin is activated

### API returns 401/403
- Verify API token in request header: `X-Article-Writer-Token`
- Check token hasn't expired

### Delete doesn't work
- Verify post ID exists
- Check user permissions (token should have delete capabilities)

## 📞 Support

If you encounter issues:
1. Check WordPress error logs
2. Check plugin logs: `/wp-content/plugins/article-writer-publisher/logs/`
3. Enable WP_DEBUG in wp-config.php for detailed errors
