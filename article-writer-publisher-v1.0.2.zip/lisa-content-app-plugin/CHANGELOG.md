# Changelog

## Version 1.0.2 (January 5, 2026)

### ✨ New Features

#### 1. Check Slug Existence API
- **Endpoint:** `GET /wp-json/article-writer/v1/check-slug`
- **Purpose:** Check if a slug already exists for a specific post type
- **Parameters:**
  - `slug` (required): The slug to check
  - `post_type` (optional, default: 'post'): The post type to check
- **Response:**
  ```json
  {
    "success": true,
    "exists": true,
    "post_id": 123,
    "post_title": "Example Post",
    "post_status": "publish",
    "post_url": "https://example.com/example-post",
    "post_type": "post"
  }
  ```

#### 2. Delete Post API
- **Endpoint:** `POST /wp-json/article-writer/v1/delete/{post_id}`
- **Purpose:** Delete a post by ID
- **Parameters:**
  - `id` (required, in URL): The post ID to delete
  - `force` (optional, default: true): Force permanent deletion (bypass trash)
- **Response:**
  ```json
  {
    "success": true,
    "message": "Post deleted successfully",
    "post_id": 123,
    "post_title": "Example Post",
    "post_slug": "example-post",
    "post_type": "post",
    "force_deleted": true
  }
  ```

### 🔧 Improvements

- Added comprehensive logging for slug checking and post deletion
- Improved error handling with proper HTTP status codes
- Better validation for input parameters
- Post queries optimized with `no_found_rows` and cache flags

### 🐛 Bug Fixes

- None in this version

### 📝 Notes

These new endpoints prevent duplicate posts when publishing from VolxAI:
1. Before creating a post, check if slug exists
2. If slug exists, delete the old post
3. Create new post with clean slug (no -2, -3 suffixes)

---

## Version 1.0.1

- Previous updates (see PLUGIN_UPDATES_v1.0.1.md)

## Version 1.0.0

- Initial release
- Basic publish and update functionality
- Token management
- Draft retrieval
- Post syncing
- Post types and taxonomies support
- Image upload functionality
